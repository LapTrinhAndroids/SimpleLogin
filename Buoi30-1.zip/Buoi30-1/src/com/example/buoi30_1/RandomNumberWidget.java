package com.example.buoi30_1;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.widget.RemoteViews;

public class RandomNumberWidget extends AppWidgetProvider {
	@Override
	public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
		//thiết lập cái giao diện cho cái widget ở trên homescreen
		RemoteViews remoteViews = new RemoteViews(context.getPackageName(), R.layout.widget_random_number);
		
		//lấy các appWidgetId
		ComponentName componentName = new ComponentName(context, RandomNumberWidget.class);
		int[] aIds = appWidgetManager.getAppWidgetIds(componentName);
		
		appWidgetManager.updateAppWidget(aIds, remoteViews);
	}
}
