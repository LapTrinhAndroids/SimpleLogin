package com.example.buoi30_1;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.widget.RemoteViews;

public class PhotoWidget extends AppWidgetProvider {
	@Override
	public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
		//tạo remoteView
		RemoteViews remoteViews = new RemoteViews(context.getPackageName(), R.layout.widget_photo);
		
		//lấy các widget đang chạy trên homescree
		ComponentName provider = new ComponentName(context, PhotoWidget.class);
		int[] wIds = appWidgetManager.getAppWidgetIds(provider);
		
		appWidgetManager.updateAppWidget(wIds, remoteViews);
	}
}
