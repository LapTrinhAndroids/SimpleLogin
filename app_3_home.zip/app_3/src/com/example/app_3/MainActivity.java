package com.example.app_3;

import java.io.IOException;
import java.io.InputStream;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		ListView lvInfor				=(ListView) findViewById(R.id.lvInfor);
		lvInfor.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
				Intent intent = new Intent(MainActivity.this,InforActivity.class);
				
				try {
					InputStream inputStream = getAssets().open((arg2)+".txt");
					int size = inputStream.available();
					byte[] buffer = new byte[size];
					inputStream.read(buffer);
					inputStream.close();
					intent.putExtra("index", new String(buffer));
					startActivity(intent);
				} catch (IOException e) {
					Toast.makeText(MainActivity.this, "Dont read file!", Toast.LENGTH_LONG).show();
				}
			}
		});
	}
}
