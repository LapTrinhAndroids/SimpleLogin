package com.example.app_3;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class InforActivity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_information);
		
		TextView txtView				=(TextView) findViewById(R.id.txtView);
		
		Intent intent					= getIntent();
		String str = intent.getStringExtra("index");
		txtView.setText(str);
		Button btnBack					=(Button) findViewById(R.id.btnBack);
		btnBack.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				startActivity(new Intent(InforActivity.this,MainActivity.class));
			}
		});
	}
}
