package com.example.app_2;

import android.app.Activity;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.SeekBar;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		final CheckBox ckUseRinger				=(CheckBox) findViewById(R.id.ckUseRingerforAll);
		final SeekBar sbRinger					=(SeekBar) findViewById(R.id.sbRinger);
		final SeekBar sbNotifications				=(SeekBar) findViewById(R.id.sbNotifications);
		final SeekBar sbMedia						=(SeekBar) findViewById(R.id.sbMedia);
		final SeekBar sbAlarm						=(SeekBar) findViewById(R.id.sbAlarm);
		final SeekBar sbVoiceCall					=(SeekBar) findViewById(R.id.sbVoiceCall);
		final SeekBar sbSystem					=(SeekBar) findViewById(R.id.sbSystem);
		
		SharedPreferences sharedPreferences = getSharedPreferences("com.example.app_2.settings", MODE_PRIVATE);
		
		ckUseRinger.setChecked(sharedPreferences.getBoolean("checked",true));
		sbRinger.setProgress(sharedPreferences.getInt("ringer", 4));
		sbNotifications.setProgress(sharedPreferences.getInt("notification", 4));
		sbMedia.setProgress(sharedPreferences.getInt("media", 8));
		sbAlarm.setProgress(sharedPreferences.getInt("alarm", 4));
		sbVoiceCall.setProgress(sharedPreferences.getInt("voice", 3));
		sbSystem.setProgress(sharedPreferences.getInt("system", 4));
		
		Button btnRestoreDefault					=(Button) findViewById(R.id.btnRestoreDefault);
		btnRestoreDefault.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				ckUseRinger.setChecked(true);
				sbRinger.setProgress(4);
				sbNotifications.setProgress(4);
				sbMedia.setProgress(8);
				sbAlarm.setProgress(4);
				sbVoiceCall.setProgress(3);
				sbSystem.setProgress(4);
			}
		});
	}
	
	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		
		final CheckBox ckUseRinger					=(CheckBox) findViewById(R.id.ckUseRingerforAll);
		final SeekBar sbRinger						=(SeekBar) findViewById(R.id.sbRinger);
		final SeekBar sbNotifications				=(SeekBar) findViewById(R.id.sbNotifications);
		final SeekBar sbMedia						=(SeekBar) findViewById(R.id.sbMedia);
		final SeekBar sbAlarm						=(SeekBar) findViewById(R.id.sbAlarm);
		final SeekBar sbVoiceCall					=(SeekBar) findViewById(R.id.sbVoiceCall);
		final SeekBar sbSystem						=(SeekBar) findViewById(R.id.sbSystem);
		
		SharedPreferences sharedPreferences			=	getSharedPreferences("com.example.app_2.settings", MODE_PRIVATE);
		Editor editor = sharedPreferences.edit();
		
		editor.putBoolean("checked",ckUseRinger.isChecked());
		editor.putInt("ringer", sbRinger.getProgress());
		editor.putInt("notification", sbNotifications.getProgress());
		editor.putInt("media", sbMedia.getProgress());
		editor.putInt("alarm", sbAlarm.getProgress());
		editor.putInt("voice", sbVoiceCall.getProgress());
		editor.putInt("system", sbSystem.getProgress());
		
		editor.commit();
	}
}
