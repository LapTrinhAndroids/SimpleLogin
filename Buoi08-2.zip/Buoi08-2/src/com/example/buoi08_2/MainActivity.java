package com.example.buoi08_2;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		
		//đã có lớp dữ liệu của mỗi item trong List
		//List<ListItem> items = null;// new List<ListItem>();
		ArrayList<ListItem> items = new ArrayList<ListItem>();
		
		items.add(new ListItem("Anh Đang Nơi Đâu", "Miu Lê"));
		items.add(new ListItem("Đếm Ngày Xa Em", "OnlyC, Lou Hoàng"));
		items.add(new ListItem("Tri Kỷ", "Phan Mạnh Quỳnh"));
		items.add(new ListItem("Anh Cứ Đi Đi", "Hari Won"));
		items.add(new ListItem("Cause I Love You", "Noo Phước Thịnh"));
		items.add(new ListItem("Sau Tất Cả", "ERIK ST.319"));
		items.add(new ListItem("Đến Bao Giờ", "Khởi My"));
		
		//đã có Adapter tự xây
		ListAdapter lAdap = new ListAdapter(this, 0, items);
		
		//cần listView
		ListView listView = (ListView) findViewById(R.id.listView);
		listView.setAdapter(lAdap);
	}
}
