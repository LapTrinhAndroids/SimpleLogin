/**
 * 
 */
package com.example.buoi08_2;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

/**
 * @author giangdn
 *
 */
public class ListAdapter extends ArrayAdapter<ListItem> {

	List<ListItem> items;
	Context mContext;
	
	public ListAdapter(Context context, int resource, List<ListItem> objects) {
		super(context, resource, objects);
		
		//tương thích
		items = objects;
		this.mContext = context;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		View v;
		//chạy qua mỗi mục trong mảng dữ liệu this.items
		
		//tạo thành cái View (của 1 mục trong ListView)
		LayoutInflater lInflater = LayoutInflater.from(this.mContext);
		//LayoutInflater có chức năng cho phép tạo thành cái view từ cái layout .xml
		
		v = lInflater.inflate(R.layout.list_item, null);
		
		//đặt dữ liệu của mỗi mục lên trên giao diện (1 mục)
		TextView textViewItemName = (TextView) v.findViewById(R.id.textViewItemName);
		
		//?? hiểu chửa
		ListItem i = this.items.get(position);
		textViewItemName.setText(i.strName);
		
		//this.items.get(position).strName
		
		TextView textViewItemDesc = (TextView) v.findViewById(R.id.textViewItemDesc);
		textViewItemDesc.setText(this.items.get(position).strDesc);
		
		//trả về
		return v;
	}
}
