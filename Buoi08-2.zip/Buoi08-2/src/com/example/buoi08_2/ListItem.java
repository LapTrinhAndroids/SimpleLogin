/**
 * 
 */
package com.example.buoi08_2;

/**
 * @author giangdn
 *
 */
public class ListItem {
	public String strName;
	public String strDesc;
	
	public ListItem(String strName, String strDesc)
	{
		this.strName = strName;
		this.strDesc = strDesc;
	}
}
