package com.example.buoi30_1;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.RemoteViews;

public class PhotoWidget extends AppWidgetProvider {
	String test;
	@Override
	public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
		//tạo remoteView
		RemoteViews remoteViews = new RemoteViews(context.getPackageName(), R.layout.widget_photo);
		
		//lấy các widget đang chạy trên homescree
		ComponentName provider = new ComponentName(context, PhotoWidget.class);
		int[] wIds = appWidgetManager.getAppWidgetIds(provider);
		
		/*for(int i=0;i<wIds.length;i++){
			int wId = wIds[i];
		}*/
		
		for(int wId: wIds){
			//Intent mang đủ thông tin để chính PhotoWidget đứng ra nhận
			Intent it = new Intent(context, PhotoWidget.class);
			it.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
			it.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, wIds);
			
			//nếu mà người dùng click thì đổi hình ảnh
			if(this.test.equals("hinhMoi")){
				remoteViews.setImageViewResource(R.id.imageViewPhotoWidget, R.drawable.wedding);
				it.putExtra("com.example.buoi30_1.test", "hinhCu");
			}else if(this.test.equals("hinhCu")){
				remoteViews.setImageViewResource(R.id.imageViewPhotoWidget, R.drawable.hoasen);
				it.putExtra("com.example.buoi30_1.test", "hinhMoi");
			}else{
				it.putExtra("com.example.buoi30_1.test", "hinhMoi");
			}
			
			//Cần PendingIntent mang Intent này chờ người dùng click
			PendingIntent pendingIntent = PendingIntent.getBroadcast(context, 0, it, PendingIntent.FLAG_UPDATE_CURRENT);
			
			//click vào hình thì làm việc gì đó
			remoteViews.setOnClickPendingIntent(R.id.imageViewPhotoWidget, pendingIntent);
			
			Log.e("onUpdate", this.test);
			
			//cập nhật lại hiển thị của các widget
			appWidgetManager.updateAppWidget(wId, remoteViews);
		}
	}
	
	@Override
	public void onReceive(Context context, Intent intent) {
		//String test = intent.getStringExtra("com.example.buoi30_1.test");
		test = intent.getExtras().getString("com.example.buoi30_1.test", " ");
		//Log.e("test", test);
		
		super.onReceive(context, intent);
	}
}
